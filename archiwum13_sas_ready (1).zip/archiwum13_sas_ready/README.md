# ArCH 13 SAS - gotowe archiwum statyczne

## Jak uruchomić lokalnie

```bash
python3 -m http.server 8000
```

Wejdź w przeglądarce na:

```text
http://localhost:8000
```

## Jak dodać dokumenty

1. PDF wrzuć do `data/pdfs/`.
2. JPG/PNG wrzuć do `data/images/`.
3. Dopisz rekord w `data/manifest.json`.

Typy:

- `pdf` dla PDF
- `image` dla JPG/PNG
- `note` dla notatek HTML

## Netlify

Wrzuć cały katalog do Netlify jako statyczną stronę. Pliki muszą zachować ścieżki.
